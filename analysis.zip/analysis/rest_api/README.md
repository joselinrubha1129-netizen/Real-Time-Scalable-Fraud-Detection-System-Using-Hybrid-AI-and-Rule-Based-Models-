# SentinelAI REST API Service

The high-throughput, enterprise RESTful API for the **Real-Time Scalable Fraud Detection System**.

---

## Folder Structure

```
rest_api/
├── main.py                 # FastAPI application with OpenAPI 3.0 & Swagger UI
├── auth.py                 # JWT token generation & Role-Based Access Control (RBAC)
├── schemas.py              # Pydantic validation schemas
├── run_api.py              # Standalone REST API launcher
└── README.md               # REST API documentation
```

---

## Interactive Documentation

- **Swagger UI Interactive Docs**: [http://127.0.0.1:8000/docs](http://127.0.0.1:8000/docs)
- **ReDoc Technical Specifications**: [http://127.0.0.1:8000/redoc](http://127.0.0.1:8000/redoc)

---

## Core API Endpoints

### 1. Fraud Scoring & Stream Simulation
- `POST /api/v1/predict`: Real-time transaction scoring (Hybrid AI + Rules).
- `POST /api/v1/stream/simulate`: Ingests simulated high-throughput Kafka/Kinesis batches.

### 2. Dynamic Rule Management
- `GET /api/v1/rules`: List all active rules and their precision/fire rates.
- `PATCH /api/v1/rules/{rule_id}`: Enable or disable a rule dynamically.

### 3. Investigation & Case Lifecycle
- `GET /api/v1/cases`: List active investigation cases.
- `GET /api/v1/cases/{case_id}`: Get full case details, evidence, and audit history.
- `PATCH /api/v1/cases/{case_id}`: Update case status, assign investigator, add notes.
- `GET /api/v1/alerts`: View recent high/critical severity alerts.
- `GET /api/v1/audit/trail`: Retrieve immutable audit trail for AML compliance.

### 4. Model Analytics & Curves
- `GET /api/v1/analytics/metrics`: Accuracy (99.36%), F1 (0.9838), ROC-AUC (0.9953), Confusion Matrix.
- `GET /api/v1/analytics/curves`: ROC curves, Precision-Recall curves, and threshold sensitivity coordinates.
- `GET /api/v1/analytics/export?format=csv`: Export cases for AML filing.

---

## How to Launch

Run the standalone REST API launcher:
```bash
python rest_api/run_api.py
```
Starts the FastAPI service on `http://127.0.0.1:8000`.
