"""
Hybrid Fraud Detection Engine
Integrates Supervised ML (LightGBM, XGBoost, Random Forest),
Unsupervised Anomaly Detection (Isolation Forest),
and Dynamic Rule Engine with graceful fallback.
"""

import os
import joblib
import numpy as np
import pandas as pd
from typing import Dict, Any, Tuple
from rules.rule_engine import DynamicRuleEngine
from models.explainability import FraudExplainabilityEngine

NUMERICAL_FEATURES = [
    "amount",
    "avg_amount_30d",
    "amount_to_avg_ratio",
    "distance_from_home_km",
    "transactions_last_24h",
    "failed_pin_attempts_last_hour",
    "hour_of_day",
    "velocity_score",
    "is_new_device",
    "is_foreign_transaction",
    "is_night",
    "is_weekend",
]

CATEGORICAL_FEATURES = [
    "channel",
    "merchant_category",
]


class HybridFraudEngine:
    def __init__(self, models_dir: str = "models/saved_models"):
        self.models_dir = models_dir
        self.rule_engine = DynamicRuleEngine()
        self.is_ml_ready = False
        self.preprocessor = None
        self.lgb_model = None
        self.xgb_model = None
        self.rf_model = None
        self.iso_forest = None
        self.explainability = None
        self.threshold = 0.35

        self.load_artifacts()

    def load_artifacts(self):
        """Loads serialized models and preprocessors from disk."""
        try:
            prep_path = os.path.join(self.models_dir, "preprocessor.joblib")
            lgb_path = os.path.join(self.models_dir, "lgb_model.joblib")
            xgb_path = os.path.join(self.models_dir, "xgb_model.joblib")
            rf_path = os.path.join(self.models_dir, "rf_model.joblib")
            iso_path = os.path.join(self.models_dir, "iso_forest.joblib")

            if all(os.path.exists(p) for p in [prep_path, lgb_path, xgb_path, rf_path, iso_path]):
                self.preprocessor = joblib.load(prep_path)
                self.lgb_model = joblib.load(lgb_path)
                self.xgb_model = joblib.load(xgb_path)
                self.rf_model = joblib.load(rf_path)
                self.iso_forest = joblib.load(iso_path)

                # Initialize explainability engine
                cat_names = self.preprocessor.named_transformers_["cat"].get_feature_names_out(CATEGORICAL_FEATURES).tolist()
                all_names = NUMERICAL_FEATURES + cat_names
                self.explainability = FraudExplainabilityEngine(self.preprocessor, self.lgb_model, all_names)
                self.is_ml_ready = True
                print("Hybrid ML Models loaded successfully!")
            else:
                print("Warning: Model files not found. Operating in Rule-Only fallback mode.")
        except Exception as e:
            print(f"Error loading models: {e}. Falling back to Rule-Based scoring.")
            self.is_ml_ready = False

    def _prepare_dataframe(self, txn: Dict[str, Any]) -> pd.DataFrame:
        """Ensures all required features exist and computes engineered ratios."""
        amount = float(txn.get("amount") or 0.0)
        avg_amount = float(txn.get("avg_amount_30d") or 100.0)
        ratio_val = txn.get("amount_to_avg_ratio")
        ratio = float(ratio_val) if ratio_val is not None else float(amount / max(avg_amount, 1e-5))
        txns_24h = int(txn.get("transactions_last_24h") or 1)
        failed = int(txn.get("failed_pin_attempts_last_hour") or 0)
        hour = int(txn.get("hour_of_day") if txn.get("hour_of_day") is not None else 12)
        
        is_night_val = txn.get("is_night")
        is_night = int(is_night_val) if is_night_val is not None else int(1 if (hour >= 23 or hour <= 4) else 0)
        
        is_weekend_val = txn.get("is_weekend")
        is_weekend = int(is_weekend_val) if is_weekend_val is not None else 0
        
        vel_val = txn.get("velocity_score")
        velocity = float(vel_val) if vel_val is not None else float((txns_24h * 1.5) + (ratio * 2.0) + (failed * 3.0))

        data = {
            "amount": [amount],
            "avg_amount_30d": [avg_amount],
            "amount_to_avg_ratio": [ratio],
            "distance_from_home_km": [float(txn.get("distance_from_home_km") or 10.0)],
            "transactions_last_24h": [txns_24h],
            "failed_pin_attempts_last_hour": [failed],
            "hour_of_day": [hour],
            "velocity_score": [velocity],
            "is_new_device": [int(txn.get("is_new_device") or 0)],
            "is_foreign_transaction": [int(txn.get("is_foreign_transaction") or 0)],
            "is_night": [is_night],
            "is_weekend": [is_weekend],
            "channel": [str(txn.get("channel") or "mobile_app")],
            "merchant_category": [str(txn.get("merchant_category") or "grocery")]
        }
        return pd.DataFrame(data)

    def score_transaction(self, txn: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes hybrid scoring:
        Risk Score (0 - 100) = 0.60 * ML_Probability + 0.15 * Anomaly_Score + 0.25 * Rule_Penalty
        """
        # 1. Rule Engine Evaluation
        rule_eval = self.rule_engine.evaluate(txn)
        rule_score = rule_eval["rule_score"]  # 0 to 100

        # 2. Supervised & Unsupervised ML scoring
        ml_prob = 0.0
        anomaly_score = 0.0
        ml_mode = "HYBRID_AI_ACTIVE"

        if self.is_ml_ready:
            try:
                df_input = self._prepare_dataframe(txn)
                X_trans = self.preprocessor.transform(df_input)

                # Supervised Ensemble
                prob_lgb = float(self.lgb_model.predict_proba(X_trans)[0][1])
                prob_xgb = float(self.xgb_model.predict_proba(X_trans)[0][1])
                prob_rf = float(self.rf_model.predict_proba(X_trans)[0][1])
                ml_prob = (prob_lgb * 0.45) + (prob_xgb * 0.40) + (prob_rf * 0.15)

                # Unsupervised Anomaly Score (Isolation Forest decision function)
                # Raw scores typically in [-0.5, 0.5]; higher negative = more anomalous
                raw_anomaly = float(self.iso_forest.decision_function(X_trans)[0])
                # Normalize raw anomaly to 0 - 1
                anomaly_score = float(np.clip(0.5 - raw_anomaly, 0.0, 1.0))
            except Exception as e:
                print(f"ML inference error: {e}. Gracefully falling back to rule scoring.")
                ml_mode = "GRACEFUL_RULE_FALLBACK"
                ml_prob = rule_score / 100.0
        else:
            ml_mode = "GRACEFUL_RULE_FALLBACK"
            ml_prob = rule_score / 100.0

        # 3. Hybrid Composite Risk Score (0 to 100)
        if ml_mode == "HYBRID_AI_ACTIVE":
            composite_risk = (ml_prob * 60.0) + (anomaly_score * 15.0) + (rule_score * 0.25)
        else:
            composite_risk = float(rule_score)

        composite_risk = round(float(np.clip(composite_risk, 0.0, 100.0)), 1)

        # 4. Risk Tiers and Prescriptive Recommendation
        if composite_risk >= 75.0:
            risk_tier = "CRITICAL"
            is_fraud = True
            decision = "DECLINE_AND_FREEZE"
            recommendation = "Decline transaction immediately and temporarily freeze account pending identity verification."
        elif composite_risk >= 50.0:
            risk_tier = "HIGH"
            is_fraud = True
            decision = "MANUAL_REVIEW"
            recommendation = "Route to fraud analyst queue for immediate investigation. Hold settlement."
        elif composite_risk >= 25.0:
            risk_tier = "MEDIUM"
            is_fraud = False
            decision = "STEP_UP_MFA"
            recommendation = "Require secondary Multi-Factor Authentication (SMS/Biometric) before approving."
        else:
            risk_tier = "LOW"
            is_fraud = False
            decision = "APPROVE"
            recommendation = "Approve transaction without friction."

        # 5. Explainability Factors
        explanations = []
        if self.explainability:
            explanations = self.explainability.explain_transaction(txn)

        # 6. Confidence Interval
        confidence = round(float(max(ml_prob, 1.0 - ml_prob) * 100), 1)

        return {
            "transaction_id": txn.get("transaction_id", "TXN-TEST"),
            "risk_score": composite_risk,
            "risk_tier": risk_tier,
            "is_fraud": is_fraud,
            "decision": decision,
            "recommendation": recommendation,
            "confidence_pct": confidence,
            "mode": ml_mode,
            "components": {
                "ml_probability": round(ml_prob, 4),
                "anomaly_score": round(anomaly_score, 4),
                "rule_penalty": rule_score
            },
            "triggered_rules": rule_eval["triggered_rules"],
            "top_risk_drivers": explanations
        }
