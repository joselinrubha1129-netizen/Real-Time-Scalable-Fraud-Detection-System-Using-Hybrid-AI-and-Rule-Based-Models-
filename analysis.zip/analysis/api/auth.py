"""
Authentication & Role-Based Access Control (RBAC) Module
Provides JWT generation, verification, and role guards for API endpoints.
"""

import datetime
import hashlib
from typing import Dict, Optional
import jwt
from fastapi import HTTPException, Security, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

SECRET_KEY = "fraud-detection-enterprise-secret-key-production"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24

# Demo enterprise users matching functional specification
DEMO_USERS: Dict[str, Dict] = {
    "admin": {
        "password_hash": hashlib.sha256("AdminSecurePass123!".encode()).hexdigest(),
        "role": "ADMIN",
        "full_name": "Chief Security Officer"
    },
    "analyst": {
        "password_hash": hashlib.sha256("AnalystPass123!".encode()).hexdigest(),
        "role": "FRAUD_ANALYST",
        "full_name": "Senior Fraud Specialist"
    },
    "auditor": {
        "password_hash": hashlib.sha256("AuditorPass123!".encode()).hexdigest(),
        "role": "AUDITOR",
        "full_name": "Regulatory AML Auditor"
    },
    "datascientist": {
        "password_hash": hashlib.sha256("DataSciPass123!".encode()).hexdigest(),
        "role": "DATA_SCIENTIST",
        "full_name": "ML Engineer"
    },
    "support": {
        "password_hash": hashlib.sha256("SupportPass123!".encode()).hexdigest(),
        "role": "CUSTOMER_SUPPORT",
        "full_name": "Customer Care Specialist"
    }
}

security = HTTPBearer(auto_error=False)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return hashlib.sha256(plain_password.encode()).hexdigest() == hashed_password


def authenticate_user(username: str, password: str) -> Optional[Dict]:
    user = DEMO_USERS.get(username.lower())
    if not user:
        return None
    if not verify_password(password, user["password_hash"]):
        return None
    return {"username": username.lower(), "role": user["role"], "full_name": user["full_name"]}


def create_access_token(data: dict, expires_delta: Optional[datetime.timedelta] = None) -> str:
    to_encode = data.copy()
    expire = datetime.datetime.utcnow() + (expires_delta or datetime.timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES))
    to_encode.update({"exp": expire})
    return jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)


def get_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Security(security)) -> Dict:
    """Decode JWT bearer token and return user identity and role."""
    if not credentials:
        # Default analyst mock user for direct browser exploration if unauthenticated
        return {"username": "analyst", "role": "FRAUD_ANALYST", "full_name": "Senior Fraud Specialist"}

    token = credentials.credentials
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        role: str = payload.get("role")
        if username is None or role is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid authentication token credentials",
                headers={"WWW-Authenticate": "Bearer"},
            )
        return {"username": username, "role": role}
    except jwt.PyJWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )


def require_roles(allowed_roles: list):
    """Dependency helper to enforce RBAC permissions."""
    def role_checker(current_user: Dict = Security(get_current_user)):
        if current_user["role"] not in allowed_roles and current_user["role"] != "ADMIN":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Operation not permitted for role {current_user['role']}"
            )
        return current_user
    return role_checker
