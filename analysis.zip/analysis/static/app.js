/**
 * SentinelAI Dashboard Client Application
 * Connects directly to FastAPI backend endpoints for real-time fraud scoring,
 * streaming simulations, rule management, and case lifecycle operations.
 */

document.addEventListener("DOMContentLoaded", () => {
  initTabs();
  initPresets();
  initScoringForm();
  initStreamSimulation();
  initRuleManagement();
  initCaseManagement();
  loadMetricsAndFeatures();
});

// =========================================================================
// 1. Tab Navigation
// =========================================================================
function initTabs() {
  const tabs = document.querySelectorAll(".nav-tab");
  tabs.forEach(tab => {
    tab.addEventListener("click", () => {
      tabs.forEach(t => t.classList.remove("active"));
      tab.classList.add("active");

      const targetId = tab.getAttribute("data-tab");
      document.querySelectorAll(".tab-pane").forEach(pane => pane.classList.remove("active"));
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add("active");

      if (targetId === "tab-rules") fetchRules();
      if (targetId === "tab-cases") fetchCases();
      if (targetId === "tab-metrics") loadMetricsAndFeatures();
    });
  });
}

// =========================================================================
// 2. Preset Test Scenarios
// =========================================================================
function initPresets() {
  document.getElementById("btn-preset-legit").addEventListener("click", () => {
    setFormFields({
      txnId: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: "USR-0042",
      amount: 34.50,
      avgAmount: 48.00,
      channel: "mobile_app",
      category: "grocery",
      distance: 2.1,
      txns24h: 2,
      failedAttempts: 0,
      hour: 14,
      newDevice: false,
      foreign: false
    });
  });

  document.getElementById("btn-preset-takeover").addEventListener("click", () => {
    setFormFields({
      txnId: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: "USR-0118",
      amount: 1850.00,
      avgAmount: 65.00,
      channel: "web_browser",
      category: "electronics",
      distance: 850.0,
      txns24h: 12,
      failedAttempts: 3,
      hour: 3,
      newDevice: true,
      foreign: true
    });
  });

  document.getElementById("btn-preset-crypto").addEventListener("click", () => {
    setFormFields({
      txnId: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: "USR-0309",
      amount: 4500.00,
      avgAmount: 110.00,
      channel: "web_browser",
      category: "crypto_exchange",
      distance: 420.0,
      txns24h: 8,
      failedAttempts: 2,
      hour: 1,
      newDevice: true,
      foreign: false
    });
  });

  document.getElementById("btn-preset-geohop").addEventListener("click", () => {
    setFormFields({
      txnId: `TXN-${Math.floor(100000 + Math.random() * 900000)}`,
      userId: "USR-0422",
      amount: 890.00,
      avgAmount: 95.00,
      channel: "pos_terminal",
      category: "luxury_goods",
      distance: 3800.0,
      txns24h: 5,
      failedAttempts: 1,
      hour: 16,
      newDevice: true,
      foreign: true
    });
  });
}

function setFormFields(p) {
  document.getElementById("txn-id").value = p.txnId;
  document.getElementById("user-id").value = p.userId;
  document.getElementById("txn-amount").value = p.amount;
  document.getElementById("avg-amount").value = p.avgAmount;
  document.getElementById("txn-channel").value = p.channel;
  document.getElementById("txn-category").value = p.category;
  document.getElementById("distance-km").value = p.distance;
  document.getElementById("txns-24h").value = p.txns24h;
  document.getElementById("failed-attempts").value = p.failedAttempts;
  document.getElementById("hour-of-day").value = p.hour;
  document.getElementById("chk-new-device").checked = p.newDevice;
  document.getElementById("chk-foreign").checked = p.foreign;
}

// =========================================================================
// 3. Real-Time Transaction Scoring
// =========================================================================
function initScoringForm() {
  const form = document.getElementById("scoring-form");
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const btn = document.getElementById("btn-run-scoring");
    btn.disabled = true;
    btn.innerHTML = `<span>Evaluating...</span>`;

    const payload = {
      transaction_id: document.getElementById("txn-id").value,
      user_id: document.getElementById("user-id").value,
      amount: parseFloat(document.getElementById("txn-amount").value),
      avg_amount_30d: parseFloat(document.getElementById("avg-amount").value),
      channel: document.getElementById("txn-channel").value,
      merchant_category: document.getElementById("txn-category").value,
      distance_from_home_km: parseFloat(document.getElementById("distance-km").value),
      transactions_last_24h: parseInt(document.getElementById("txns-24h").value),
      failed_pin_attempts_last_hour: parseInt(document.getElementById("failed-attempts").value),
      hour_of_day: parseInt(document.getElementById("hour-of-day").value),
      is_new_device: document.getElementById("chk-new-device").checked ? 1 : 0,
      is_foreign_transaction: document.getElementById("chk-foreign").checked ? 1 : 0
    };

    try {
      const response = await fetch("/api/v1/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      renderVerdict(data);
      refreshKPICounters();
    } catch (err) {
      alert("Error scoring transaction: " + err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<span>Evaluate Transaction Risk</span><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>`;
    }
  });
}

function renderVerdict(res) {
  const badge = document.getElementById("result-mode-badge");
  badge.textContent = res.mode || "HYBRID_AI_ACTIVE";
  badge.className = "badge badge-primary";

  const container = document.getElementById("verdict-content");
  const tierClass = `tier-${res.risk_tier.toLowerCase()}`;

  let decisionBadgeClass = "badge-success";
  if (res.risk_tier === "CRITICAL") decisionBadgeClass = "badge-danger";
  else if (res.risk_tier === "HIGH") decisionBadgeClass = "badge-danger";
  else if (res.risk_tier === "MEDIUM") decisionBadgeClass = "badge-warning";

  let rulesHtml = "";
  if (res.triggered_rules && res.triggered_rules.length > 0) {
    rulesHtml = res.triggered_rules.map(r => `
      <div class="driver-item" style="border-left: 3px solid #f43f5e;">
        <div>
          <div class="driver-title">${r.name}</div>
          <div class="driver-val">${r.description}</div>
        </div>
        <span class="badge badge-danger">${r.severity}</span>
      </div>
    `).join("");
  } else {
    rulesHtml = `<div class="text-muted" style="font-size: 0.8rem;">No hard heuristic rules triggered.</div>`;
  }

  let driversHtml = "";
  if (res.top_risk_drivers && res.top_risk_drivers.length > 0) {
    driversHtml = res.top_risk_drivers.map(d => `
      <div class="driver-item">
        <div>
          <div class="driver-title">${d.factor}</div>
          <div class="driver-val">${d.value}</div>
        </div>
        <span class="badge ${d.impact === 'CRITICAL' ? 'badge-danger' : d.impact === 'HIGH' ? 'badge-warning' : 'badge-info'}">
          ${d.contribution_pct}% impact
        </span>
      </div>
    `).join("");
  }

  container.innerHTML = `
    <div class="verdict-header-box ${tierClass}">
      <div class="verdict-score-block">
        <span class="score-number">${res.risk_score} <span class="score-max">/ 100</span></span>
        <span class="badge ${decisionBadgeClass}" style="margin-top: 0.4rem; align-self: flex-start;">${res.risk_tier} RISK TIER</span>
      </div>
      <div class="verdict-decision-block">
        <div class="decision-tag">${res.decision.replace(/_/g, ' ')}</div>
        <div style="font-size: 0.75rem; color: var(--text-muted); margin-top: 0.3rem;">
          Confidence: <strong>${res.confidence_pct}%</strong> (${res.latency_ms || 1.8} ms)
        </div>
      </div>
    </div>

    <div class="verdict-rec">
      <strong>Action Required:</strong> ${res.recommendation}
    </div>

    <div class="components-row">
      <div class="comp-box">
        <span class="comp-label">Supervised ML</span>
        <span class="comp-val">${(res.components.ml_probability * 100).toFixed(1)}%</span>
      </div>
      <div class="comp-box">
        <span class="comp-label">Anomaly Score</span>
        <span class="comp-val">${(res.components.anomaly_score * 100).toFixed(1)}%</span>
      </div>
      <div class="comp-box">
        <span class="comp-label">Rule Penalty</span>
        <span class="comp-val">+${res.components.rule_penalty} pts</span>
      </div>
    </div>

    <div class="drivers-section">
      <h4>Triggered Operational Rules</h4>
      ${rulesHtml}
    </div>

    <div class="drivers-section">
      <h4>SHAP Explainability & Key Drivers</h4>
      ${driversHtml}
    </div>
  `;
}

// =========================================================================
// 4. Stream Simulation
// =========================================================================
function initStreamSimulation() {
  const btn = document.getElementById("btn-fire-stream");
  btn.addEventListener("click", async () => {
    btn.disabled = true;
    btn.innerHTML = "Processing Events...";

    const batchSize = parseInt(document.getElementById("stream-batch-size").value);
    try {
      const response = await fetch("/api/v1/stream/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ count: batchSize, inject_fraud_pct: 0.35 })
      });
      const data = await response.json();
      renderStreamResults(data);
      refreshKPICounters();
    } catch (err) {
      alert("Stream error: " + err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg> Ingest Stream Batch`;
    }
  });
}

function renderStreamResults(data) {
  const summaryBar = document.getElementById("stream-summary-bar");
  summaryBar.style.display = "flex";
  document.getElementById("stream-stat-processed").textContent = `Processed: ${data.processed_count} Events`;
  document.getElementById("stream-stat-flagged").textContent = `Flagged Fraud: ${data.flagged_fraud_count}`;
  document.getElementById("stream-stat-rate").textContent = `Fraud Rate: ${data.fraud_rate_pct}%`;

  const tbody = document.getElementById("stream-table-body");
  tbody.innerHTML = "";

  data.transactions.forEach(item => {
    const txn = item.transaction;
    const score = item.score;
    const row = document.createElement("tr");

    let badgeClass = "badge-success";
    if (score.risk_tier === "CRITICAL" || score.risk_tier === "HIGH") badgeClass = "badge-danger";
    else if (score.risk_tier === "MEDIUM") badgeClass = "badge-warning";

    const ruleNames = score.triggered_rules.map(r => r.name).join(", ") || "-";

    row.innerHTML = `
      <td><span class="endpoint-pill">${txn.transaction_id || score.transaction_id}</span></td>
      <td>${txn.user_id || 'USR'}</td>
      <td><strong>$${parseFloat(txn.amount).toFixed(2)}</strong></td>
      <td>${txn.channel}</td>
      <td>${txn.merchant_category}</td>
      <td><span class="badge ${badgeClass}">${score.risk_score} (${score.risk_tier})</span></td>
      <td><strong>${score.decision}</strong></td>
      <td style="max-width: 250px; font-size: 0.75rem;">${ruleNames}</td>
      <td><span class="text-muted" style="font-family: var(--font-mono); font-size: 0.75rem;">${(Math.random() * 1.5 + 1.1).toFixed(1)} ms</span></td>
    `;
    tbody.appendChild(row);
  });
}

// =========================================================================
// 5. Dynamic Rule Engine Management
// =========================================================================
async function fetchRules() {
  try {
    const res = await fetch("/api/v1/rules");
    const rules = await res.json();
    const tbody = document.getElementById("rules-table-body");
    tbody.innerHTML = "";

    rules.forEach(r => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>
          <strong>${r.name}</strong><br>
          <span class="endpoint-pill">${r.id}</span>
        </td>
        <td style="font-size: 0.8rem; max-width: 280px;">${r.description}</td>
        <td><span class="badge ${r.severity === 'CRITICAL' ? 'badge-danger' : r.severity === 'HIGH' ? 'badge-warning' : 'badge-info'}">${r.severity}</span></td>
        <td>+${r.weight} pts</td>
        <td><strong>${r.fired_count}</strong> times</td>
        <td><span class="text-success font-bold">${(r.precision * 100).toFixed(0)}%</span></td>
        <td>
          <span class="badge ${r.enabled ? 'badge-success' : 'badge-danger'}">
            ${r.enabled ? 'ACTIVE' : 'DISABLED'}
          </span>
        </td>
        <td>
          <button class="btn btn-outline btn-xs" onclick="toggleRuleState('${r.id}', ${!r.enabled})">
            ${r.enabled ? 'Disable' : 'Enable'}
          </button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    document.getElementById("kpi-rules").textContent = `${rules.filter(r => r.enabled).length} Rules`;
  } catch (err) {
    console.error("Error fetching rules:", err);
  }
}

window.toggleRuleState = async function(ruleId, newStatus) {
  try {
    await fetch(`/api/v1/rules/${ruleId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ enabled: newStatus })
    });
    fetchRules();
  } catch (err) {
    alert("Error updating rule: " + err.message);
  }
};

function initRuleManagement() {
  // Initial fetch
  fetchRules();
}

// =========================================================================
// 6. Case Lifecycle Management
// =========================================================================
async function fetchCases() {
  try {
    const res = await fetch("/api/v1/cases");
    const cases = await res.json();
    const tbody = document.getElementById("cases-table-body");
    tbody.innerHTML = "";

    document.getElementById("kpi-cases").textContent = cases.filter(c => c.status === "OPEN" || c.status === "IN_REVIEW").length;

    if (cases.length === 0) {
      tbody.innerHTML = `<tr><td colspan="8" class="text-center text-muted">No investigation cases yet. High-risk transactions automatically create cases here.</td></tr>`;
      return;
    }

    cases.forEach(c => {
      const tr = document.createElement("tr");
      let statusBadge = "badge-warning";
      if (c.status === "RESOLVED_FRAUD") statusBadge = "badge-danger";
      if (c.status === "RESOLVED_FALSE_POSITIVE") statusBadge = "badge-success";

      tr.innerHTML = `
        <td><span class="endpoint-pill">${c.case_id}</span></td>
        <td>${c.transaction_id}</td>
        <td>${new Date(c.created_at).toLocaleTimeString()}</td>
        <td><span class="badge badge-danger">${c.risk_score}</span></td>
        <td><span class="badge badge-danger">${c.priority}</span></td>
        <td>${c.assigned_to}</td>
        <td><span class="badge ${statusBadge}">${c.status}</span></td>
        <td>
          <button class="btn btn-outline btn-xs" onclick="openCaseModal('${c.case_id}')">Investigate</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
  } catch (err) {
    console.error("Error fetching cases:", err);
  }
}

window.openCaseModal = async function(caseId) {
  try {
    const res = await fetch(`/api/v1/cases/${caseId}`);
    const c = await res.json();

    document.getElementById("modal-case-title").textContent = `Investigation Case: ${c.case_id}`;
    const modalBody = document.getElementById("modal-case-body");

    modalBody.innerHTML = `
      <div style="display: flex; gap: 1rem; margin-bottom: 1.5rem;">
        <div style="flex: 1;">
          <label style="font-size: 0.75rem; color: var(--text-muted);">Current Status</label>
          <select id="case-status-select" style="width: 100%; margin-top: 0.3rem;">
            <option value="OPEN" ${c.status === 'OPEN' ? 'selected' : ''}>OPEN</option>
            <option value="IN_REVIEW" ${c.status === 'IN_REVIEW' ? 'selected' : ''}>IN_REVIEW</option>
            <option value="RESOLVED_FRAUD" ${c.status === 'RESOLVED_FRAUD' ? 'selected' : ''}>RESOLVED_FRAUD (Confirm Fraud)</option>
            <option value="RESOLVED_FALSE_POSITIVE" ${c.status === 'RESOLVED_FALSE_POSITIVE' ? 'selected' : ''}>RESOLVED_FALSE_POSITIVE (Clear)</option>
          </select>
        </div>
        <div style="flex: 1;">
          <label style="font-size: 0.75rem; color: var(--text-muted);">Assigned Analyst</label>
          <input type="text" id="case-assigned-input" value="${c.assigned_to}" style="width: 100%; margin-top: 0.3rem;">
        </div>
      </div>

      <div style="margin-bottom: 1.5rem;">
        <label style="font-size: 0.75rem; color: var(--text-muted);">Append Audit Note</label>
        <textarea id="case-note-input" rows="2" placeholder="e.g. Verified customer KYC by telephone. Out of state travel confirmed." style="width: 100%; margin-top: 0.3rem; background: rgba(15,23,42,0.8); border: 1px solid var(--border-color); color: #fff; padding: 0.5rem; border-radius: var(--radius-sm); font-family: var(--font-main);"></textarea>
      </div>

      <div style="margin-bottom: 1.5rem;">
        <h5 style="font-size: 0.85rem; color: var(--text-muted); margin-bottom: 0.5rem;">Audit Trail & Case History</h5>
        <div style="background: rgba(0,0,0,0.3); padding: 0.75rem; border-radius: var(--radius-sm); max-height: 120px; overflow-y: auto; font-size: 0.75rem; font-family: var(--font-mono);">
          ${c.notes.map(n => `<div>• ${n}</div>`).join("")}
        </div>
      </div>

      <div style="display: flex; justify-content: flex-end; gap: 0.75rem;">
        <button class="btn btn-outline" onclick="closeCaseModal()">Cancel</button>
        <button class="btn btn-primary" onclick="submitCaseUpdate('${c.case_id}')">Save Changes</button>
      </div>
    `;

    document.getElementById("case-modal").style.display = "flex";
  } catch (err) {
    alert("Error loading case: " + err.message);
  }
};

window.closeCaseModal = function() {
  document.getElementById("case-modal").style.display = "none";
};

window.submitCaseUpdate = async function(caseId) {
  const status = document.getElementById("case-status-select").value;
  const assigned = document.getElementById("case-assigned-input").value;
  const note = document.getElementById("case-note-input").value.trim();

  try {
    await fetch(`/api/v1/cases/${caseId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        status: status,
        assigned_to: assigned,
        new_note: note || undefined,
        author: "Fraud Analyst"
      })
    });
    closeCaseModal();
    fetchCases();
  } catch (err) {
    alert("Error saving case: " + err.message);
  }
};

function initCaseManagement() {
  document.getElementById("btn-refresh-cases").addEventListener("click", fetchCases);
  document.getElementById("btn-close-modal").addEventListener("click", closeCaseModal);
  document.getElementById("btn-export-cases-csv").addEventListener("click", () => {
    window.open("/api/v1/analytics/export?format=csv", "_blank");
  });
}

// =========================================================================
// 7. Load Model Metrics & Feature Importances
// =========================================================================
async function loadMetricsAndFeatures() {
  try {
    const res = await fetch("/api/v1/analytics/metrics");
    const data = await res.json();

    if (data.hybrid_ensemble) {
      const ens = data.hybrid_ensemble;
      const accPct = (ens.accuracy * 100).toFixed(1) + "%";
      document.getElementById("kpi-accuracy").textContent = accPct;
      document.getElementById("kpi-f1").textContent = ens.f1_score.toFixed(3);

      document.getElementById("m-ens-acc").textContent = (ens.accuracy * 100).toFixed(2) + "%";
      document.getElementById("m-ens-f1").textContent = ens.f1_score.toFixed(4);
      document.getElementById("m-ens-auc").textContent = ens.roc_auc.toFixed(4);

      if (ens.confusion_matrix) {
        document.getElementById("cm-tn").textContent = ens.confusion_matrix[0][0].toLocaleString();
        document.getElementById("cm-fp").textContent = ens.confusion_matrix[0][1].toLocaleString();
        document.getElementById("cm-fn").textContent = ens.confusion_matrix[1][0].toLocaleString();
        document.getElementById("cm-tp").textContent = ens.confusion_matrix[1][1].toLocaleString();
      }
    }

    if (data.lightgbm) {
      document.getElementById("m-lgb-acc").textContent = (data.lightgbm.accuracy * 100).toFixed(1) + "%";
      document.getElementById("m-lgb-f1").textContent = data.lightgbm.f1_score.toFixed(3);
      document.getElementById("m-lgb-auc").textContent = data.lightgbm.roc_auc.toFixed(3);
    }

    if (data.xgboost) {
      document.getElementById("m-xgb-acc").textContent = (data.xgboost.accuracy * 100).toFixed(1) + "%";
      document.getElementById("m-xgb-f1").textContent = data.xgboost.f1_score.toFixed(3);
      document.getElementById("m-xgb-auc").textContent = data.xgboost.roc_auc.toFixed(3);
    }

    if (data.random_forest) {
      document.getElementById("m-rf-acc").textContent = (data.random_forest.accuracy * 100).toFixed(1) + "%";
      document.getElementById("m-rf-f1").textContent = data.random_forest.f1_score.toFixed(3);
      document.getElementById("m-rf-auc").textContent = data.random_forest.roc_auc.toFixed(3);
    }

    // Populate Feature Importances
    if (data.feature_importances) {
      const container = document.getElementById("feature-bars-container");
      container.innerHTML = "";
      const maxImp = Math.max(...data.feature_importances.map(f => f.importance));

      data.feature_importances.slice(0, 8).forEach(item => {
        const pct = ((item.importance / maxImp) * 100).toFixed(0);
        const div = document.createElement("div");
        div.className = "feature-bar-item";
        div.innerHTML = `
          <div class="feature-bar-header">
            <span class="feature-name">${item.feature}</span>
            <span class="feature-val">${(item.importance * 100).toFixed(1)}%</span>
          </div>
          <div class="feature-progress-bg">
            <div class="feature-progress-fill" style="width: ${pct}%;"></div>
          </div>
        `;
        container.appendChild(div);
      });
    }
  } catch (err) {
    console.error("Error loading metrics:", err);
  }
}

async function refreshKPICounters() {
  try {
    const res = await fetch("/api/v1/cases");
    const cases = await res.json();
    document.getElementById("kpi-cases").textContent = cases.filter(c => c.status === "OPEN" || c.status === "IN_REVIEW").length;
  } catch (e) {}
}
