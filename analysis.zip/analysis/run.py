"""
One-Click Launch Script for SentinelAI Fraud Detection System
Ensures data is generated, models are trained, and launches the FastAPI server.
"""

import os
import sys
import uvicorn

def main():
    print("=================================================================")
    print("  SentinelAI: Real-Time Scalable Fraud Detection System")
    print("  Using Hybrid AI (LightGBM, XGBoost, RF, Isolation Forest)")
    print("=================================================================")

    # 1. Verify / Generate Data
    if not os.path.exists("data/transactions.csv"):
        print("\n[Step 1/3] Generating synthetic transaction dataset...")
        from data.generator import generate_and_save_data
        generate_and_save_data()
    else:
        print("\n[Step 1/3] Dataset already exists at data/transactions.csv")

    # 2. Verify / Train Models
    if not os.path.exists("models/saved_models/lgb_model.joblib"):
        print("\n[Step 2/3] Training ML models (LightGBM, XGBoost, Random Forest, Isolation Forest)...")
        from models.train import train_models
        train_models()
    else:
        print("\n[Step 2/3] Serialized ML models loaded.")

    # 3. Launch Server
    print("\n[Step 3/3] Starting FastAPI server on http://127.0.0.1:8000 ...")
    print("  - Web Dashboard:     http://127.0.0.1:8000")
    print("  - OpenAPI Swagger:   http://127.0.0.1:8000/docs")
    print("  - ReDoc Specs:       http://127.0.0.1:8000/redoc")
    print("=================================================================\n")

    uvicorn.run("rest_api.main:app", host="127.0.0.1", port=8000, reload=False)


if __name__ == "__main__":
    main()
