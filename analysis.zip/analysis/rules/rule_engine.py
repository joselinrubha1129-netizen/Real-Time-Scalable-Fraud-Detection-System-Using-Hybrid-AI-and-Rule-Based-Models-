"""
Dynamic Financial Fraud Rule Engine
Allows defining, testing, evaluating, and tracking dynamic fraud rules with logical chaining.
"""

from typing import Dict, List, Any, Optional
import datetime


class DynamicRuleEngine:
    def __init__(self):
        # Default active rule set
        self.rules = {
            "RULE_VELOCITY_SPIKE": {
                "id": "RULE_VELOCITY_SPIKE",
                "name": "High Velocity Transaction Spike",
                "description": "Triggered when composite velocity score exceeds 25.0 or 24h transactions > 10",
                "enabled": True,
                "severity": "HIGH",
                "weight": 25,
                "fired_count": 0,
                "tp_count": 0,
                "fp_count": 0,
                "condition": lambda txn: (
                    txn.get("velocity_score", 0) > 25.0 or txn.get("transactions_last_24h", 0) >= 10
                )
            },
            "RULE_GEO_ANOMALY": {
                "id": "RULE_GEO_ANOMALY",
                "name": "Impossible Travel / Geo-Distance Jump",
                "description": "Distance from registered home > 1200 km or foreign transaction from a new device",
                "enabled": True,
                "severity": "CRITICAL",
                "weight": 35,
                "fired_count": 0,
                "tp_count": 0,
                "fp_count": 0,
                "condition": lambda txn: (
                    txn.get("distance_from_home_km", 0) > 1200.0 or
                    (txn.get("is_foreign_transaction", 0) == 1 and txn.get("is_new_device", 0) == 1)
                )
            },
            "RULE_AMOUNT_DEVIATION": {
                "id": "RULE_AMOUNT_DEVIATION",
                "name": "Extreme Amount Deviation",
                "description": "Transaction amount is > 5x user's historical 30-day average",
                "enabled": True,
                "severity": "HIGH",
                "weight": 25,
                "fired_count": 0,
                "tp_count": 0,
                "fp_count": 0,
                "condition": lambda txn: (
                    txn.get("amount_to_avg_ratio", 0) > 5.0 and txn.get("amount", 0) > 300.0
                )
            },
            "RULE_PIN_BRUTE_FORCE": {
                "id": "RULE_PIN_BRUTE_FORCE",
                "name": "Repeated Failed Verification",
                "description": ">= 3 failed verification/PIN attempts in previous hour",
                "enabled": True,
                "severity": "CRITICAL",
                "weight": 30,
                "fired_count": 0,
                "tp_count": 0,
                "fp_count": 0,
                "condition": lambda txn: txn.get("failed_pin_attempts_last_hour", 0) >= 3
            },
            "RULE_MIDNIGHT_CRYPTO": {
                "id": "RULE_MIDNIGHT_CRYPTO",
                "name": "Nocturnal High-Risk Merchant Purchase",
                "description": "Transaction between 23:00 - 04:00 at crypto_exchange or luxury_goods > $400",
                "enabled": True,
                "severity": "MEDIUM",
                "weight": 20,
                "fired_count": 0,
                "tp_count": 0,
                "fp_count": 0,
                "condition": lambda txn: (
                    txn.get("is_night", 0) == 1 and
                    txn.get("merchant_category") in ["crypto_exchange", "luxury_goods"] and
                    txn.get("amount", 0) > 400.0
                )
            }
        }

    def evaluate(self, txn: Dict[str, Any], ground_truth: Optional[int] = None) -> Dict[str, Any]:
        """
        Evaluate all enabled rules for a transaction.
        Returns triggered rules, total penalty score, and highest severity.
        """
        triggered_rules = []
        total_penalty = 0
        severities = []

        for rule_id, rule in self.rules.items():
            if not rule["enabled"]:
                continue

            try:
                if rule["condition"](txn):
                    triggered_rules.append({
                        "rule_id": rule_id,
                        "name": rule["name"],
                        "severity": rule["severity"],
                        "weight": rule["weight"],
                        "description": rule["description"]
                    })
                    total_penalty += rule["weight"]
                    severities.append(rule["severity"])
                    rule["fired_count"] += 1

                    if ground_truth is not None:
                        if ground_truth == 1:
                            rule["tp_count"] += 1
                        else:
                            rule["fp_count"] += 1
            except Exception:
                continue

        # Cap rule penalty at 100
        total_penalty = min(100, total_penalty)

        # Determine dominant severity
        if "CRITICAL" in severities:
            overall_severity = "CRITICAL"
        elif "HIGH" in severities:
            overall_severity = "HIGH"
        elif "MEDIUM" in severities:
            overall_severity = "MEDIUM"
        else:
            overall_severity = "LOW"

        return {
            "triggered_rules": triggered_rules,
            "rule_count": len(triggered_rules),
            "rule_score": total_penalty,
            "rule_severity": overall_severity
        }

    def get_rules_metadata(self) -> List[Dict[str, Any]]:
        """Return list of all rules and their performance stats."""
        result = []
        for r_id, r in self.rules.items():
            total = r["fired_count"]
            precision = round(r["tp_count"] / total, 3) if total > 0 else 1.0
            result.append({
                "id": r["id"],
                "name": r["name"],
                "description": r["description"],
                "enabled": r["enabled"],
                "severity": r["severity"],
                "weight": r["weight"],
                "fired_count": r["fired_count"],
                "tp_count": r["tp_count"],
                "fp_count": r["fp_count"],
                "precision": precision
            })
        return result

    def toggle_rule(self, rule_id: str, enabled: bool) -> bool:
        if rule_id in self.rules:
            self.rules[rule_id]["enabled"] = enabled
            return True
        return False

    def add_custom_rule(self, rule_id: str, name: str, description: str, 
                        severity: str, weight: int, condition_fn) -> None:
        self.rules[rule_id] = {
            "id": rule_id,
            "name": name,
            "description": description,
            "enabled": True,
            "severity": severity,
            "weight": weight,
            "fired_count": 0,
            "tp_count": 0,
            "fp_count": 0,
            "condition": condition_fn
        }
