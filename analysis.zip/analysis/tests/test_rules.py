"""
Test Suite: Dynamic Rule Engine Verification
"""

import pytest
from rules.rule_engine import DynamicRuleEngine


def test_velocity_rule_trigger():
    engine = DynamicRuleEngine()
    txn = {
        "velocity_score": 32.5,
        "transactions_last_24h": 14,
        "amount": 200,
        "amount_to_avg_ratio": 2.0
    }
    eval_res = engine.evaluate(txn)
    rule_ids = [r["rule_id"] for r in eval_res["triggered_rules"]]
    assert "RULE_VELOCITY_SPIKE" in rule_ids
    assert eval_res["rule_score"] >= 25


def test_geo_anomaly_rule_trigger():
    engine = DynamicRuleEngine()
    txn = {
        "distance_from_home_km": 2500.0,
        "is_foreign_transaction": 1,
        "is_new_device": 1
    }
    eval_res = engine.evaluate(txn)
    rule_ids = [r["rule_id"] for r in eval_res["triggered_rules"]]
    assert "RULE_GEO_ANOMALY" in rule_ids
    assert eval_res["rule_severity"] == "CRITICAL"


def test_rule_toggle():
    engine = DynamicRuleEngine()
    assert engine.rules["RULE_VELOCITY_SPIKE"]["enabled"] is True
    engine.toggle_rule("RULE_VELOCITY_SPIKE", False)
    assert engine.rules["RULE_VELOCITY_SPIKE"]["enabled"] is False

    txn = {"velocity_score": 45.0, "transactions_last_24h": 20}
    eval_res = engine.evaluate(txn)
    rule_ids = [r["rule_id"] for r in eval_res["triggered_rules"]]
    assert "RULE_VELOCITY_SPIKE" not in rule_ids
