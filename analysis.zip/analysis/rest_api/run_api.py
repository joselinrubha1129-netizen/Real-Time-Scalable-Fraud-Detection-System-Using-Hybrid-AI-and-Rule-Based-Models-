"""
Standalone REST API Server Launcher
Runs the FastAPI service on http://127.0.0.1:8000 with OpenAPI Swagger docs at /docs
"""

import os
import sys

# Ensure root workspace is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import uvicorn

if __name__ == "__main__":
    print("===============================================================")
    print("  SentinelAI REST API Service")
    print("  OpenAPI Documentation: http://127.0.0.1:8000/docs")
    print("  ReDoc Specs:           http://127.0.0.1:8000/redoc")
    print("===============================================================")
    uvicorn.run("rest_api.main:app", host="127.0.0.1", port=8000, reload=False)
