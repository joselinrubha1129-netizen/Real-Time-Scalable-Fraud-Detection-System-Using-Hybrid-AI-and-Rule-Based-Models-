"""
Pydantic Schemas for Request & Response Data Validation
"""

from typing import Dict, List, Any, Optional
from pydantic import BaseModel, Field


class TransactionRequest(BaseModel):
    transaction_id: Optional[str] = Field(default="TXN-SAMPLE", description="Unique transaction ID")
    user_id: Optional[str] = Field(default="USR-0042", description="User / Account ID")
    amount: float = Field(..., gt=0, description="Transaction amount in currency units")
    avg_amount_30d: Optional[float] = Field(default=120.0, description="User's 30-day baseline average amount")
    amount_to_avg_ratio: Optional[float] = None
    channel: str = Field(default="mobile_app", description="Channel: mobile_app, web_browser, pos_terminal, atm")
    merchant_category: str = Field(default="grocery", description="Merchant category")
    distance_from_home_km: float = Field(default=12.5, description="Distance from registered home in km")
    location_lat: Optional[float] = 37.7749
    location_lon: Optional[float] = -122.4194
    device_id: Optional[str] = "DEV-84920"
    is_new_device: int = Field(default=0, ge=0, le=1)
    is_foreign_transaction: int = Field(default=0, ge=0, le=1)
    failed_pin_attempts_last_hour: int = Field(default=0, ge=0)
    transactions_last_24h: int = Field(default=2, ge=0)
    hour_of_day: int = Field(default=14, ge=0, le=23)
    is_night: Optional[int] = 0
    is_weekend: Optional[int] = 0
    velocity_score: Optional[float] = None


class RuleTriggerDetail(BaseModel):
    rule_id: str
    name: str
    severity: str
    weight: int
    description: str


class RiskDriver(BaseModel):
    factor: str
    impact: str
    value: str
    contribution_pct: float


class PredictionResponse(BaseModel):
    transaction_id: str
    risk_score: float
    risk_tier: str
    is_fraud: bool
    decision: str
    recommendation: str
    confidence_pct: float
    mode: str
    components: Dict[str, Any]
    triggered_rules: List[RuleTriggerDetail]
    top_risk_drivers: List[RiskDriver]


class StreamSimulationRequest(BaseModel):
    count: int = Field(default=10, ge=1, le=100, description="Number of stream transactions to generate & score")
    inject_fraud_pct: float = Field(default=0.30, ge=0.0, le=1.0, description="Percentage of simulated fraud")


class StreamItemResponse(BaseModel):
    transaction: Dict[str, Any]
    score_result: PredictionResponse


class RuleToggleRequest(BaseModel):
    enabled: bool


class CaseUpdateRequest(BaseModel):
    status: Optional[str] = None
    assigned_to: Optional[str] = None
    new_note: Optional[str] = None
    author: Optional[str] = "Analyst"


class TokenRequest(BaseModel):
    username: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    role: str
    username: str
