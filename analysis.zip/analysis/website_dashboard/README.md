# SentinelAI Website Dashboard

The modern, responsive executive web application for the **Real-Time Scalable Fraud Detection System**.

---

## Folder Structure

```
website_dashboard/
├── index.html              # HTML5 single-page application structure
├── styles.css              # Cyber-fintech glassmorphic styling
├── app.js                  # Frontend client communicating with REST API
├── charts/                 # High-resolution model diagnostic charts
│   ├── confusion_matrix.png
│   ├── roc_curves.png
│   ├── precision_recall.png
│   └── threshold_analysis.png
├── serve_dashboard.py      # Standalone runner (serves dashboard on port 3000)
└── README.md               # Dashboard documentation
```

---

## Dashboard Features

1. **Real-Time Scoring Simulator**:
   - Interactive transaction risk evaluation form.
   - 4 Pre-built test scenarios:
     - 🛒 *Normal Grocery ($35)*: Approved instantly with $< 2\text{ ms}$ latency.
     - 🔓 *Account Takeover ($1,850)*: High-value burst attack flagged for decline and freeze.
     - 🌙 *Midnight Crypto ($4,500)*: Nocturnal high-risk merchant transaction flagged.
     - ✈️ *Impossible Travel ($890)*: Geo-jump anomaly detected and halted.
   - Shows composite risk score (0-100), risk tier, prescriptive action, confidence, and SHAP explainability drivers.

2. **Stream Processing Monitor**:
   - Real-time batch ingestion simulator (Apache Kafka / AWS Kinesis emulation).
   - Ingests 5 to 50 concurrent transactions with sub-second decisioning.

3. **Model Accuracy & Visual Metrics Gallery**:
   - Live KPI cards: **99.36% Accuracy**, **0.9838 F1-Score**, **~1.8 ms Latency**.
   - Model benchmark comparison across Hybrid Ensemble, LightGBM, XGBoost, Random Forest, and Isolation Forest.
   - Confusion Matrix (3,750 test transactions).
   - Embedded high-res visual charts for ROC curves, Precision-Recall curves, and Decision Threshold Tuning.

4. **Dynamic Rule Engine Studio**:
   - Manage operational rules (Velocity Spikes, Impossible Travel, Nocturnal Crypto, PIN Brute Force).
   - Live toggles to enable/disable rules in real-time.

5. **Investigation Case Lifecycle**:
   - Filter cases (`OPEN`, `IN_REVIEW`, `RESOLVED_FRAUD`, `RESOLVED_FALSE_POSITIVE`).
   - Investigator assignment, evidence review, and audit trail note appending.
   - One-click CSV export for regulatory AML filings.

---

## How to Launch

### Option A: Via Integrated Backend (Default)
When starting the API service (`python run.py` or `python rest_api/run_api.py`), the dashboard is automatically served at:
👉 **[http://127.0.0.1:8000](http://127.0.0.1:8000)**

### Option B: Standalone Web Server
To run the website dashboard as a dedicated standalone frontend service:
```bash
python website_dashboard/serve_dashboard.py
```
Then visit:
👉 **[http://127.0.0.1:3000](http://127.0.0.1:3000)**
(The dashboard automatically connects to the backend REST API running on port 8000).
