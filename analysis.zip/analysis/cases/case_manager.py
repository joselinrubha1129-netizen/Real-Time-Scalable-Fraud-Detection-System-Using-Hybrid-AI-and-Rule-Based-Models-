"""
Case Management & Fraud Investigation Lifecycle
Handles alerts, case conversion, analyst assignments, evidence attachments, and tamper-evident audit logs.
"""

import datetime
import uuid
from typing import Dict, List, Any, Optional


class CaseManager:
    def __init__(self):
        self.cases: Dict[str, Dict[str, Any]] = {}
        self.alerts: List[Dict[str, Any]] = []
        self.audit_logs: List[Dict[str, Any]] = []

    def create_alert(self, score_result: Dict[str, Any], raw_txn: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Creates an alert if transaction exceeds the risk threshold."""
        risk_score = score_result.get("risk_score", 0.0)
        risk_tier = score_result.get("risk_tier", "LOW")

        if risk_score < 40.0:
            return None

        alert_id = f"ALT-{str(uuid.uuid4())[:8].upper()}"
        alert = {
            "alert_id": alert_id,
            "transaction_id": score_result.get("transaction_id"),
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "risk_score": risk_score,
            "risk_tier": risk_tier,
            "decision": score_result.get("decision"),
            "amount": raw_txn.get("amount", 0.0),
            "user_id": raw_txn.get("user_id", "N/A"),
            "triggered_rules": [r["name"] for r in score_result.get("triggered_rules", [])],
            "severity": "CRITICAL" if risk_score >= 75 else "HIGH",
            "status": "UNRESOLVED"
        }
        self.alerts.append(alert)

        # Automatically convert CRITICAL alerts to formal investigation cases
        if risk_tier == "CRITICAL":
            self.create_case_from_alert(alert, score_result, raw_txn, assigned_to="Fraud Analyst Queue")

        return alert

    def create_case_from_alert(self, alert: Dict[str, Any], score_result: Dict[str, Any], 
                               raw_txn: Dict[str, Any], assigned_to: str = "Unassigned") -> Dict[str, Any]:
        """Convert a flagged transaction into a full investigation case."""
        case_id = f"CASE-{str(uuid.uuid4())[:8].upper()}"
        case = {
            "case_id": case_id,
            "transaction_id": alert.get("transaction_id"),
            "alert_id": alert.get("alert_id"),
            "created_at": datetime.datetime.utcnow().isoformat() + "Z",
            "updated_at": datetime.datetime.utcnow().isoformat() + "Z",
            "status": "OPEN",  # OPEN, IN_REVIEW, ESCALATED, RESOLVED_FRAUD, RESOLVED_FALSE_POSITIVE
            "assigned_to": assigned_to,
            "priority": alert.get("severity", "HIGH"),
            "risk_score": alert.get("risk_score", 0.0),
            "transaction_data": raw_txn,
            "score_result": score_result,
            "evidence": [
                {
                    "type": "MODEL_SCORE",
                    "content": f"Hybrid AI composite score {alert.get('risk_score')}/100 ({score_result.get('risk_tier')})",
                    "added_at": datetime.datetime.utcnow().isoformat() + "Z"
                }
            ],
            "notes": [
                f"Auto-generated case from high severity trigger on {raw_txn.get('transaction_id', 'TXN')}"
            ]
        }
        self.cases[case_id] = case

        # Audit log entry
        self._record_audit(case_id, "CASE_CREATED", f"Investigation case created with priority {case['priority']}")
        return case

    def update_case(self, case_id: str, status: Optional[str] = None, 
                    assigned_to: Optional[str] = None, new_note: Optional[str] = None, 
                    author: str = "Analyst") -> Optional[Dict[str, Any]]:
        """Update case state, assignee, or add notes with audit tracking."""
        if case_id not in self.cases:
            return None

        case = self.cases[case_id]
        if status:
            old_status = case["status"]
            case["status"] = status
            self._record_audit(case_id, "STATUS_CHANGE", f"Status updated from {old_status} to {status}", author)

        if assigned_to:
            case["assigned_to"] = assigned_to
            self._record_audit(case_id, "ASSIGNMENT_CHANGE", f"Reassigned to {assigned_to}", author)

        if new_note:
            timestamped_note = f"[{datetime.datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} by {author}] {new_note}"
            case["notes"].append(timestamped_note)
            self._record_audit(case_id, "NOTE_ADDED", new_note, author)

        case["updated_at"] = datetime.datetime.utcnow().isoformat() + "Z"
        return case

    def list_cases(self, status: Optional[str] = None) -> List[Dict[str, Any]]:
        all_cases = list(self.cases.values())
        if status:
            return [c for c in all_cases if c["status"].upper() == status.upper()]
        return sorted(all_cases, key=lambda x: x["created_at"], reverse=True)

    def list_alerts(self, limit: int = 50) -> List[Dict[str, Any]]:
        return sorted(self.alerts, key=lambda x: x["timestamp"], reverse=True)[:limit]

    def _record_audit(self, case_id: str, action: str, details: str, user: str = "System"):
        self.audit_logs.append({
            "log_id": f"AUDIT-{len(self.audit_logs)+1:06d}",
            "case_id": case_id,
            "action": action,
            "details": details,
            "user": user,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z"
        })

    def get_audit_trail(self, case_id: Optional[str] = None) -> List[Dict[str, Any]]:
        if case_id:
            return [l for l in self.audit_logs if l["case_id"] == case_id]
        return sorted(self.audit_logs, key=lambda x: x["timestamp"], reverse=True)
