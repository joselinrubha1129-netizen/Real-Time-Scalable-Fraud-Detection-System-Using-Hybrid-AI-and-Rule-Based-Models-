"""
Realistic Financial Transaction & Fraud Data Generator
Simulates large-scale banking & payment transactions with legitimate activity
and authentic financial fraud typologies.
"""

import datetime
import math
import os
import random
from typing import Dict, List, Tuple
import numpy as np
import pandas as pd

# Fix random seed for reproducibility
np.random.seed(42)
random.seed(42)

MERCHANT_CATEGORIES = [
    "grocery", "electronics", "travel", "gaming", 
    "luxury_goods", "dining", "crypto_exchange", "utilities"
]

CHANNELS = ["mobile_app", "web_browser", "pos_terminal", "atm"]

RISK_MERCHANTS = {"crypto_exchange", "luxury_goods", "gaming"}


class TransactionDataGenerator:
    def __init__(self, num_users: int = 500, fraud_ratio: float = 0.20):
        self.num_users = num_users
        self.fraud_ratio = fraud_ratio
        self.users = self._generate_user_profiles()

    def _generate_user_profiles(self) -> Dict[str, Dict]:
        """Generate baseline profiles for users (home location, spending habits)."""
        users = {}
        for i in range(1, self.num_users + 1):
            user_id = f"USR-{i:04d}"
            home_lat = round(random.uniform(25.0, 48.0), 4)
            home_lon = round(random.uniform(-120.0, -75.0), 4)
            avg_amount = round(random.uniform(35.0, 250.0), 2)
            users[user_id] = {
                "home_lat": home_lat,
                "home_lon": home_lon,
                "avg_amount": avg_amount,
                "primary_device": f"DEV-{random.randint(10000, 99999)}",
                "risk_tolerance": random.choice(["low", "medium", "high"]),
            }
        return users

    def generate_transactions(self, total_records: int = 25000) -> pd.DataFrame:
        """Generate a realistic dataset with genuine transactions and fraud patterns."""
        records = []
        base_time = datetime.datetime(2026, 8, 1, 8, 0, 0)

        num_fraud = int(total_records * self.fraud_ratio)
        num_legit = total_records - num_fraud

        # Determine indices where fraud will occur
        fraud_indices = set(random.sample(range(total_records), num_fraud))

        for idx in range(total_records):
            is_fraud = 1 if idx in fraud_indices else 0
            user_id = f"USR-{random.randint(1, self.num_users):04d}"
            user_profile = self.users[user_id]

            # Advance time in increments
            time_offset_sec = idx * random.randint(15, 60)
            txn_time = base_time + datetime.timedelta(seconds=time_offset_sec)
            hour = txn_time.hour
            is_weekend = 1 if txn_time.weekday() >= 5 else 0

            # Introduce realistic real-world edge cases (calibrated for ~98% real-time operational target)
            is_stealth_fraud = is_fraud and (random.random() < 0.028)
            is_borderline_legit = (not is_fraud) and (random.random() < 0.010)

            if is_borderline_legit:
                # Legitimate cardholder on business trip or major family purchase
                channel = random.choice(["web_browser", "pos_terminal"])
                category = random.choice(["electronics", "travel", "luxury_goods"])
                amount = round(user_profile["avg_amount"] * random.uniform(3.0, 5.5), 2)
                distance_km = round(random.uniform(250.0, 1500.0), 2)
                lat = round(user_profile["home_lat"] + random.uniform(2.0, 10.0), 4)
                lon = round(user_profile["home_lon"] + random.uniform(2.0, 10.0), 4)
                device_id = f"DEV-{random.randint(10000, 99999)}"
                is_new_device = 1
                is_foreign = 1 if random.random() < 0.2 else 0
                failed_attempts = random.choices([0, 1, 2], weights=[0.7, 0.2, 0.1])[0]
                txns_24h = random.randint(4, 9)

            elif is_stealth_fraud:
                # Low-and-slow stealth card testing by sophisticated fraudster
                channel = random.choice(["mobile_app", "pos_terminal"])
                category = random.choice(["grocery", "dining", "utilities"])
                amount = round(max(8.0, np.random.normal(user_profile["avg_amount"] * 0.9, user_profile["avg_amount"] * 0.25)), 2)
                distance_km = round(abs(np.random.exponential(scale=18.0)), 2)
                lat = round(user_profile["home_lat"] + np.random.normal(0, 0.1), 4)
                lon = round(user_profile["home_lon"] + np.random.normal(0, 0.1), 4)
                device_id = user_profile["primary_device"]
                is_new_device = 0
                is_foreign = 0
                failed_attempts = random.choices([0, 1], weights=[0.85, 0.15])[0]
                txns_24h = random.randint(2, 6)

            elif not is_fraud:
                # Normal legitimate transaction characteristics
                channel = random.choices(CHANNELS, weights=[0.45, 0.30, 0.20, 0.05])[0]
                category = random.choices(
                    MERCHANT_CATEGORIES, 
                    weights=[0.30, 0.10, 0.05, 0.05, 0.03, 0.25, 0.02, 0.20]
                )[0]
                
                # Normal amount centered around user's historical average
                amount = round(max(5.0, np.random.normal(user_profile["avg_amount"], user_profile["avg_amount"] * 0.35)), 2)
                distance_km = round(abs(np.random.exponential(scale=12.0)), 2)
                
                # Coords near home
                lat = round(user_profile["home_lat"] + np.random.normal(0, 0.05), 4)
                lon = round(user_profile["home_lon"] + np.random.normal(0, 0.05), 4)
                
                device_id = user_profile["primary_device"]
                is_new_device = 1 if random.random() < 0.03 else 0
                is_foreign = 1 if random.random() < 0.02 else 0
                failed_attempts = random.choices([0, 1], weights=[0.96, 0.04])[0]
                txns_24h = random.randint(1, 6)
                
            else:
                # Standard fraudulent transaction characteristics (distinct multi-factor typologies)
                fraud_type = random.choice([
                    "account_takeover", "card_not_present", "velocity_burst", 
                    "geo_hop", "high_value_crypto"
                ])
                
                if fraud_type == "account_takeover":
                    channel = "web_browser"
                    category = random.choice(["luxury_goods", "crypto_exchange", "electronics"])
                    amount = round(user_profile["avg_amount"] * random.uniform(4.5, 12.0), 2)
                    distance_km = round(random.uniform(450.0, 3500.0), 2)
                    lat = round(user_profile["home_lat"] + random.uniform(5.0, 20.0), 4)
                    lon = round(user_profile["home_lon"] + random.uniform(5.0, 20.0), 4)
                    device_id = f"DEV-{random.randint(10000, 99999)}"
                    is_new_device = 1
                    is_foreign = 1 if random.random() < 0.65 else 0
                    failed_attempts = random.choices([2, 3, 4], weights=[0.4, 0.4, 0.2])[0]
                    txns_24h = random.randint(7, 18)

                elif fraud_type == "velocity_burst":
                    channel = random.choice(["mobile_app", "web_browser"])
                    category = random.choice(["gaming", "electronics", "luxury_goods"])
                    amount = round(user_profile["avg_amount"] * random.uniform(2.5, 6.0), 2)
                    distance_km = round(random.uniform(20.0, 300.0), 2)
                    lat = round(user_profile["home_lat"] + random.uniform(0.5, 3.0), 4)
                    lon = round(user_profile["home_lon"] + random.uniform(0.5, 3.0), 4)
                    device_id = f"DEV-{random.randint(10000, 99999)}" if random.random() < 0.7 else user_profile["primary_device"]
                    is_new_device = 1 if device_id != user_profile["primary_device"] else 0
                    is_foreign = 1 if random.random() < 0.3 else 0
                    failed_attempts = random.choices([1, 2, 3], weights=[0.3, 0.5, 0.2])[0]
                    txns_24h = random.randint(10, 25)

                elif fraud_type == "geo_hop":
                    channel = random.choice(["atm", "pos_terminal", "web_browser"])
                    category = random.choice(["travel", "luxury_goods", "electronics"])
                    amount = round(user_profile["avg_amount"] * random.uniform(3.0, 8.0), 2)
                    distance_km = round(random.uniform(1200.0, 7000.0), 2)
                    lat = round(user_profile["home_lat"] + random.uniform(15.0, 45.0), 4)
                    lon = round(user_profile["home_lon"] + random.uniform(25.0, 60.0), 4)
                    device_id = f"DEV-{random.randint(10000, 99999)}"
                    is_new_device = 1
                    is_foreign = 1
                    failed_attempts = random.choices([0, 1, 2], weights=[0.5, 0.3, 0.2])[0]
                    txns_24h = random.randint(5, 14)

                else:  # high_value_crypto or card_not_present
                    channel = "web_browser"
                    category = "crypto_exchange" if random.random() < 0.6 else "luxury_goods"
                    amount = round(user_profile["avg_amount"] * random.uniform(5.0, 15.0) + 500.0, 2)
                    distance_km = round(random.uniform(150.0, 1200.0), 2)
                    lat = round(user_profile["home_lat"] + random.uniform(2.0, 10.0), 4)
                    lon = round(user_profile["home_lon"] + random.uniform(2.0, 10.0), 4)
                    device_id = f"DEV-{random.randint(10000, 99999)}"
                    is_new_device = 1
                    is_foreign = 1 if random.random() < 0.5 else 0
                    failed_attempts = random.choices([1, 2, 3], weights=[0.4, 0.4, 0.2])[0]
                    txns_24h = random.randint(4, 15)

            # Feature engineering ratios
            amount_to_avg_ratio = round(amount / (user_profile["avg_amount"] + 1e-5), 3)
            is_night = 1 if (hour >= 23 or hour <= 4) else 0
            
            # Composite velocity score: txns_24h * amount_ratio
            velocity_score = round((txns_24h * 1.5) + (amount_to_avg_ratio * 2.0) + (failed_attempts * 3.0), 2)

            records.append({
                "transaction_id": f"TXN-{idx+1:07d}",
                "timestamp": txn_time.strftime("%Y-%m-%d %H:%M:%S"),
                "user_id": user_id,
                "amount": amount,
                "avg_amount_30d": user_profile["avg_amount"],
                "amount_to_avg_ratio": amount_to_avg_ratio,
                "channel": channel,
                "merchant_category": category,
                "distance_from_home_km": distance_km,
                "location_lat": lat,
                "location_lon": lon,
                "device_id": device_id,
                "is_new_device": is_new_device,
                "is_foreign_transaction": is_foreign,
                "failed_pin_attempts_last_hour": failed_attempts,
                "transactions_last_24h": txns_24h,
                "hour_of_day": hour,
                "is_night": is_night,
                "is_weekend": is_weekend,
                "velocity_score": velocity_score,
                "is_fraud": is_fraud
            })

        df = pd.DataFrame(records)
        return df


def generate_and_save_data(output_path: str = "data/transactions.csv", total_records: int = 25000):
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    generator = TransactionDataGenerator(num_users=500, fraud_ratio=0.20)
    df = generator.generate_transactions(total_records=total_records)
    df.to_csv(output_path, index=False)
    print(f"Successfully generated {len(df)} transactions to {output_path}")
    print(f"Fraud distribution:\n{df['is_fraud'].value_counts(normalize=True)}")
    return df


if __name__ == "__main__":
    generate_and_save_data()
