"""
Test Suite: Model Performance & Hybrid Engine Accuracy Verification
Ensures system satisfies Accuracy >= 98% and F1-Score >= 0.98 requirements.
"""

import json
import os
import pytest
from models.hybrid_engine import HybridFraudEngine


def test_model_benchmarks_metrics():
    metrics_path = "models/saved_models/metrics.json"
    assert os.path.exists(metrics_path), "metrics.json does not exist. Train models first."

    with open(metrics_path, "r") as f:
        metrics = json.load(f)

    hybrid = metrics["hybrid_ensemble"]
    acc = hybrid["accuracy"]
    f1 = hybrid["f1_score"]

    print(f"\nVerified Model Benchmark -> Accuracy: {acc * 100:.2f}%, F1: {f1:.4f}")
    assert acc >= 0.98, f"Accuracy {acc} is below required 98% (0.98)"
    assert f1 >= 0.98, f"F1-Score {f1} is below required 0.98"


def test_hybrid_engine_legit_scoring():
    engine = HybridFraudEngine()
    legit_txn = {
        "transaction_id": "TXN-LEGIT-001",
        "amount": 25.50,
        "avg_amount_30d": 40.0,
        "distance_from_home_km": 3.0,
        "transactions_last_24h": 2,
        "failed_pin_attempts_last_hour": 0,
        "is_new_device": 0,
        "is_foreign_transaction": 0,
        "channel": "mobile_app",
        "merchant_category": "grocery"
    }
    result = engine.score_transaction(legit_txn)
    assert result["risk_score"] < 40.0
    assert result["decision"] in ["APPROVE", "STEP_UP_MFA"]
    assert not result["is_fraud"]


def test_hybrid_engine_fraud_scoring():
    engine = HybridFraudEngine()
    fraud_txn = {
        "transaction_id": "TXN-FRAUD-001",
        "amount": 3500.0,
        "avg_amount_30d": 50.0,
        "distance_from_home_km": 2800.0,
        "transactions_last_24h": 15,
        "failed_pin_attempts_last_hour": 3,
        "is_new_device": 1,
        "is_foreign_transaction": 1,
        "channel": "web_browser",
        "merchant_category": "crypto_exchange"
    }
    result = engine.score_transaction(fraud_txn)
    assert result["risk_score"] >= 70.0
    assert result["is_fraud"] is True
    assert result["decision"] in ["DECLINE_AND_FREEZE", "MANUAL_REVIEW"]
    assert len(result["triggered_rules"]) >= 1
    assert len(result["top_risk_drivers"]) >= 1
