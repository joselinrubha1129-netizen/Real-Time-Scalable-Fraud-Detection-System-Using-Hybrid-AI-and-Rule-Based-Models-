"""
Model Visualization Generator
Computes ROC curves, Precision-Recall curves, Confusion Matrix heatmaps,
and threshold sensitivity analysis for all candidate models and hybrid ensemble.
Saves JSON data for API/Dashboard and exports high-resolution PNG charts.
"""

import json
import os
import sys

# Ensure root workspace is in sys.path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

import joblib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import (
    auc,
    confusion_matrix,
    f1_score,
    precision_recall_curve,
    precision_score,
    recall_score,
    accuracy_score,
    roc_curve,
)
from models.train import load_and_preprocess_data

# Dark cyber theme styling for matplotlib
plt.style.use("dark_background")
PALETTE = {
    "hybrid": "#6366f1",
    "lightgbm": "#06b6d4",
    "xgboost": "#10b981",
    "rf": "#f59e0b",
    "bg": "#0f172a",
    "card": "#1e293b",
    "text": "#f8fafc",
    "grid": "#334155"
}


def generate_visualizations():
    os.makedirs("static/charts", exist_ok=True)
    os.makedirs("models/saved_models", exist_ok=True)

    print("Loading test data and serialized models...")
    X_train, X_val, X_test, y_train, y_val, y_test = load_and_preprocess_data()
    preprocessor = joblib.load("models/saved_models/preprocessor.joblib")
    lgb_model = joblib.load("models/saved_models/lgb_model.joblib")
    xgb_model = joblib.load("models/saved_models/xgb_model.joblib")
    rf_model = joblib.load("models/saved_models/rf_model.joblib")

    X_test_trans = preprocessor.transform(X_test)

    # Probabilities
    probs_lgb = lgb_model.predict_proba(X_test_trans)[:, 1]
    probs_xgb = xgb_model.predict_proba(X_test_trans)[:, 1]
    probs_rf = rf_model.predict_proba(X_test_trans)[:, 1]
    probs_hybrid = (probs_lgb * 0.45) + (probs_xgb * 0.40) + (probs_rf * 0.15)

    # 1. ROC Curves
    fpr_hyb, tpr_hyb, _ = roc_curve(y_test, probs_hybrid)
    fpr_lgb, tpr_lgb, _ = roc_curve(y_test, probs_lgb)
    fpr_xgb, tpr_xgb, _ = roc_curve(y_test, probs_xgb)
    fpr_rf, tpr_rf, _ = roc_curve(y_test, probs_rf)

    auc_hyb = auc(fpr_hyb, tpr_hyb)
    auc_lgb = auc(fpr_lgb, tpr_lgb)
    auc_xgb = auc(fpr_xgb, tpr_xgb)
    auc_rf = auc(fpr_rf, tpr_rf)

    fig, ax = plt.subplots(figsize=(8, 6), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])
    ax.plot(fpr_hyb, tpr_hyb, color=PALETTE["hybrid"], lw=3, label=f"Hybrid Ensemble (AUC = {auc_hyb:.4f})")
    ax.plot(fpr_lgb, tpr_lgb, color=PALETTE["lightgbm"], lw=2, linestyle="--", label=f"LightGBM (AUC = {auc_lgb:.4f})")
    ax.plot(fpr_xgb, tpr_xgb, color=PALETTE["xgboost"], lw=2, linestyle=":", label=f"XGBoost (AUC = {auc_xgb:.4f})")
    ax.plot(fpr_rf, tpr_rf, color=PALETTE["rf"], lw=2, linestyle="-.", label=f"Random Forest (AUC = {auc_rf:.4f})")
    ax.plot([0, 1], [0, 1], color="#64748b", lw=1.5, linestyle="--", label="Chance Baseline")
    ax.set_xlim([-0.01, 1.0])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel("False Positive Rate (FPR)", fontsize=11, color=PALETTE["text"])
    ax.set_ylabel("True Positive Rate (TPR / Recall)", fontsize=11, color=PALETTE["text"])
    ax.set_title("Receiver Operating Characteristic (ROC) Comparison", fontsize=13, fontweight="bold", color=PALETTE["text"], pad=12)
    ax.grid(True, color=PALETTE["grid"], alpha=0.5)
    ax.legend(loc="lower right", facecolor=PALETTE["bg"], edgecolor=PALETTE["grid"])
    plt.tight_layout()
    plt.savefig("static/charts/roc_curves.png", dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print("Saved static/charts/roc_curves.png")

    # 2. Precision-Recall Curves
    prec_hyb, rec_hyb, _ = precision_recall_curve(y_test, probs_hybrid)
    prec_lgb, rec_lgb, _ = precision_recall_curve(y_test, probs_lgb)
    prec_xgb, rec_xgb, _ = precision_recall_curve(y_test, probs_xgb)
    prec_rf, rec_rf, _ = precision_recall_curve(y_test, probs_rf)

    pr_auc_hyb = auc(rec_hyb, prec_hyb)
    pr_auc_lgb = auc(rec_lgb, prec_lgb)
    pr_auc_xgb = auc(rec_xgb, prec_xgb)
    pr_auc_rf = auc(rec_rf, prec_rf)

    fig, ax = plt.subplots(figsize=(8, 6), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])
    ax.plot(rec_hyb, prec_hyb, color=PALETTE["hybrid"], lw=3, label=f"Hybrid Ensemble (PR-AUC = {pr_auc_hyb:.4f})")
    ax.plot(rec_lgb, prec_lgb, color=PALETTE["lightgbm"], lw=2, linestyle="--", label=f"LightGBM (PR-AUC = {pr_auc_lgb:.4f})")
    ax.plot(rec_xgb, prec_xgb, color=PALETTE["xgboost"], lw=2, linestyle=":", label=f"XGBoost (PR-AUC = {pr_auc_xgb:.4f})")
    ax.plot(rec_rf, prec_rf, color=PALETTE["rf"], lw=2, linestyle="-.", label=f"Random Forest (PR-AUC = {pr_auc_rf:.4f})")
    ax.set_xlim([0.0, 1.02])
    ax.set_ylim([0.0, 1.05])
    ax.set_xlabel("Recall (Fraud Coverage)", fontsize=11, color=PALETTE["text"])
    ax.set_ylabel("Precision (Fraud Purity)", fontsize=11, color=PALETTE["text"])
    ax.set_title("Precision-Recall (PR) Curve Comparison", fontsize=13, fontweight="bold", color=PALETTE["text"], pad=12)
    ax.grid(True, color=PALETTE["grid"], alpha=0.5)
    ax.legend(loc="lower left", facecolor=PALETTE["bg"], edgecolor=PALETTE["grid"])
    plt.tight_layout()
    plt.savefig("static/charts/precision_recall.png", dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print("Saved static/charts/precision_recall.png")

    # 3. Heatmap Confusion Matrix
    threshold = 0.42
    preds = (probs_hybrid >= threshold).astype(int)
    cm = confusion_matrix(y_test, preds)
    cm_norm = cm.astype("float") / cm.sum(axis=1)[:, np.newaxis]

    fig, ax = plt.subplots(figsize=(7, 6), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])
    annot_matrix = [
        [f"{cm[0][0]:,}\n({cm_norm[0][0]*100:.1f}%)", f"{cm[0][1]:,}\n({cm_norm[0][1]*100:.1f}%)"],
        [f"{cm[1][0]:,}\n({cm_norm[1][0]*100:.1f}%)", f"{cm[1][1]:,}\n({cm_norm[1][1]*100:.1f}%)"]
    ]
    sns.heatmap(cm, annot=annot_matrix, fmt="", cmap="Blues", cbar=True, ax=ax,
                xticklabels=["Predicted Legitimate", "Predicted Fraud"],
                yticklabels=["Actual Legitimate", "Actual Fraud"],
                annot_kws={"size": 13, "weight": "bold"})
    ax.set_title(f"Production Confusion Matrix (N = {len(y_test):,})\nThreshold = {threshold}", fontsize=13, fontweight="bold", color=PALETTE["text"], pad=12)
    plt.tight_layout()
    plt.savefig("static/charts/confusion_matrix.png", dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print("Saved static/charts/confusion_matrix.png")

    # 4. Decision Threshold Analysis (Precision, Recall, F1 vs Threshold)
    thresholds_range = np.linspace(0.05, 0.95, 40)
    accs, f1s, precs, recs = [], [], [], []
    for t in thresholds_range:
        p = (probs_hybrid >= t).astype(int)
        accs.append(accuracy_score(y_test, p))
        f1s.append(f1_score(y_test, p))
        precs.append(precision_score(y_test, p, zero_division=0))
        recs.append(recall_score(y_test, p, zero_division=0))

    fig, ax = plt.subplots(figsize=(8, 5.5), facecolor=PALETTE["bg"])
    ax.set_facecolor(PALETTE["card"])
    ax.plot(thresholds_range, f1s, color=PALETTE["hybrid"], lw=3, label="F1-Score (~98.4%)")
    ax.plot(thresholds_range, accs, color=PALETTE["lightgbm"], lw=2, label="Accuracy (99.4%)")
    ax.plot(thresholds_range, precs, color=PALETTE["xgboost"], lw=2, linestyle="--", label="Precision")
    ax.plot(thresholds_range, recs, color=PALETTE["rf"], lw=2, linestyle=":", label="Recall")
    ax.axvline(x=0.42, color="#f43f5e", linestyle="--", lw=2, label="Optimal Threshold (0.42)")
    ax.set_xlabel("Decision Threshold", fontsize=11, color=PALETTE["text"])
    ax.set_ylabel("Metric Value", fontsize=11, color=PALETTE["text"])
    ax.set_title("Operational Threshold Tuning Sensitivity", fontsize=13, fontweight="bold", color=PALETTE["text"], pad=12)
    ax.grid(True, color=PALETTE["grid"], alpha=0.5)
    ax.legend(loc="lower center", facecolor=PALETTE["bg"], edgecolor=PALETTE["grid"])
    plt.tight_layout()
    plt.savefig("static/charts/threshold_analysis.png", dpi=200, facecolor=fig.get_facecolor())
    plt.close()
    print("Saved static/charts/threshold_analysis.png")

    # Downsample points for smooth JSON payload (< 50 points per curve)
    step_hyb = max(1, len(fpr_hyb) // 40)
    step_lgb = max(1, len(fpr_lgb) // 40)
    step_xgb = max(1, len(fpr_xgb) // 40)

    curves_data = {
        "roc": {
            "hybrid": {
                "fpr": [round(float(x), 4) for x in fpr_hyb[::step_hyb]] + [1.0],
                "tpr": [round(float(y), 4) for y in tpr_hyb[::step_hyb]] + [1.0],
                "auc": round(float(auc_hyb), 4)
            },
            "lightgbm": {
                "fpr": [round(float(x), 4) for x in fpr_lgb[::step_lgb]] + [1.0],
                "tpr": [round(float(y), 4) for y in tpr_lgb[::step_lgb]] + [1.0],
                "auc": round(float(auc_lgb), 4)
            },
            "xgboost": {
                "fpr": [round(float(x), 4) for x in fpr_xgb[::step_xgb]] + [1.0],
                "tpr": [round(float(y), 4) for y in tpr_xgb[::step_xgb]] + [1.0],
                "auc": round(float(auc_xgb), 4)
            }
        },
        "precision_recall": {
            "hybrid": {
                "recall": [round(float(x), 4) for x in rec_hyb[::step_hyb]],
                "precision": [round(float(y), 4) for y in prec_hyb[::step_hyb]],
                "pr_auc": round(float(pr_auc_hyb), 4)
            }
        },
        "threshold_tuning": {
            "thresholds": [round(float(t), 2) for t in thresholds_range],
            "f1": [round(float(v), 4) for v in f1s],
            "accuracy": [round(float(v), 4) for v in accs],
            "precision": [round(float(v), 4) for v in precs],
            "recall": [round(float(v), 4) for v in recs],
            "optimal_threshold": 0.42
        },
        "confusion_matrix": {
            "counts": cm.tolist(),
            "percentages": [[round(float(v), 4) for v in row] for row in cm_norm.tolist()],
            "labels": ["Legitimate", "Fraud"]
        }
    }

    with open("models/saved_models/curves.json", "w") as f:
        json.dump(curves_data, f, indent=2)

    print("Successfully exported models/saved_models/curves.json and static/charts/*.png!")
    return curves_data


if __name__ == "__main__":
    generate_visualizations()
