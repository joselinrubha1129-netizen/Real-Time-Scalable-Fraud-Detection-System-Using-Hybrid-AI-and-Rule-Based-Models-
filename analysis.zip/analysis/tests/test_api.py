"""
Test Suite: FastAPI Endpoints Integration Verification
"""

import pytest
from fastapi.testclient import TestClient
from api.main import app

client = TestClient(app)


def test_health_check_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"
    assert data["ml_ready"] is True


def test_predict_endpoint_legitimate():
    payload = {
        "transaction_id": "TXN-TEST-API-01",
        "user_id": "USR-0005",
        "amount": 28.50,
        "avg_amount_30d": 35.0,
        "channel": "mobile_app",
        "merchant_category": "grocery",
        "distance_from_home_km": 1.5,
        "transactions_last_24h": 1,
        "failed_pin_attempts_last_hour": 0,
        "hour_of_day": 12,
        "is_new_device": 0,
        "is_foreign_transaction": 0
    }
    response = client.post("/api/v1/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["transaction_id"] == "TXN-TEST-API-01"
    assert data["risk_score"] < 40.0
    assert not data["is_fraud"]
    assert "components" in data


def test_predict_endpoint_fraud():
    payload = {
        "transaction_id": "TXN-TEST-API-FRAUD",
        "user_id": "USR-0009",
        "amount": 3200.00,
        "avg_amount_30d": 60.0,
        "channel": "web_browser",
        "merchant_category": "crypto_exchange",
        "distance_from_home_km": 3200.0,
        "transactions_last_24h": 14,
        "failed_pin_attempts_last_hour": 3,
        "hour_of_day": 2,
        "is_new_device": 1,
        "is_foreign_transaction": 1
    }
    response = client.post("/api/v1/predict", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["risk_score"] >= 65.0
    assert data["is_fraud"] is True
    assert len(data["triggered_rules"]) >= 1


def test_stream_simulation_endpoint():
    response = client.post("/api/v1/stream/simulate", json={"count": 5, "inject_fraud_pct": 0.4})
    assert response.status_code == 200
    data = response.json()
    assert data["processed_count"] == 5
    assert len(data["transactions"]) == 5


def test_rules_endpoint():
    response = client.get("/api/v1/rules")
    assert response.status_code == 200
    rules = response.json()
    assert len(rules) >= 4


def test_analytics_metrics_endpoint():
    response = client.get("/api/v1/analytics/metrics")
    assert response.status_code == 200
    data = response.json()
    assert "hybrid_ensemble" in data
    assert data["hybrid_ensemble"]["accuracy"] >= 0.98


def test_analytics_curves_endpoint():
    response = client.get("/api/v1/analytics/curves")
    assert response.status_code == 200
    data = response.json()
    assert "roc" in data
    assert "confusion_matrix" in data
    assert "precision_recall" in data
    assert "threshold_tuning" in data

